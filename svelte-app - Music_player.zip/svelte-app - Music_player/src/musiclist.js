import {writable} from "svelte/store";

export const musicList = writable([

    {
        image:"yoasobi.jpg",
        audio:"YOASOBI.mp3",
        name:"YORUNIKAKERU",
        artist:"YOASOBI"
    },
    {
        image:"TABUN.png",
        audio:"Tabun.mp3",
        name:"TABUN",
        artist:"YOASOBI"
    },
    {
        image:"Gunjo.png",
        audio:"Gunjo.mp3",
        name:"GUNJO",
        artist:"YOASOBI"
    },
    {
        image:"Harushion.jpg",
        audio:"Harushion.mp3",
        name:"HARUSHION",
        artist:"YOASOBI"
    },
    {
        image:"RGB.jpg",
        audio:"RGB.mp3",
        name:"RGB",
        artist:"YOASOBI"
    },
    {
        image:"Yuseibousi.jpg",
        audio:"Yuseibousi.mp3",
        name:"YUSEIBOUSI",
        artist:"EVE"
    }
    
]);

